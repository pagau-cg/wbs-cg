// api/shared/storageHelper.js
// Shared helper — Azure Blob Storage operations for WBS projects

const { BlobServiceClient } = require("@azure/storage-blob");

const CONTAINER = "wbs-cg";
const CONNECTION = process.env.AZURE_STORAGE_CONNECTION_STRING;

/**
 * Get BlobServiceClient and ensure container exists
 */
async function getContainer() {
  if (!CONNECTION) throw new Error("STORAGE_CONNECTION_STRING non configurée");
  const client = BlobServiceClient.fromConnectionString(CONNECTION);
  const container = client.getContainerClient(CONTAINER);
  await container.createIfNotExists({ access: "private" });
  return container;
}

/**
 * Extract user UPN from Static Web App auth header
 * Returns e.g. "jdupont@constructiongauthier.com" or "anonymous"
 */
function getUserId(req) {
  try {
    const header = req.headers["x-ms-client-principal"];
    if (!header) return "anonymous";
    const decoded = Buffer.from(header, "base64").toString("utf8");
    const principal = JSON.parse(decoded);
    // Use userDetails (UPN) as unique user identifier
    return (principal.userDetails || principal.userId || "anonymous")
      .toLowerCase()
      .replace(/[^a-z0-9@._-]/g, "_");
  } catch {
    return "anonymous";
  }
}

/**
 * Build blob name : users/{userId}/projects/{projectId}.json
 */
function blobName(userId, projectId) {
  const safeId = projectId.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 64);
  return `users/${userId}/projects/${safeId}.json`;
}

module.exports = { getContainer, getUserId, blobName };
